# Adeept 4WD Smart Car Kit for Raspberry Pi PiCar-B

## About This Product

## About Adeept

Adeept is a technical service team of open source software and hardware. Dedicated to applying the Internet and the latest industrial technology in open source area, we strive to provide best hardware support and software service for general makers and electronic enthusiasts around the world. We aim to create infinite possibilities with sharing. No matter what field you are in, we can lead you into the electronic world and bring your ideas into reality.

## Contact Info
 Technical Support:  support@adeept.com<br/>
 Customer Service:   service@adeept.com<br/>
 Website:            www.adeept.com<br/>
